// Linalysis background service worker — v0.2.0
//   • multilingual SSI scraper (DE/EN/FR/ES + comma decimals), AND
//   • daily growth-metrics collection: Connections, Sent invitations (+ weekly-credit usage),
//     Profile views, Search/Profile appearances — each scraped by content-metrics.js and merged
//     server-side into the same daily stats row.
//
// Sync Now = pair if needed → open LinkedIn /sales/ssi → scrape SSI → then open the four growth
// pages and scrape each → POST /api/ingest/linkedin. Every step is logged to chrome.storage.local
// under `syncLog` so the popup can show what actually happened.

const API_BASE = 'https://api.linalysis.net';
const ALARM_NAME = 'linalysisDailySync';
const SYNC_POLL_ALARM = 'linalysisSyncPoll';
const SSI_URL = 'https://www.linkedin.com/sales/ssi';
const MAX_LOG = 40;

// Growth pages scraped each daily sync (in addition to SSI). content-metrics.js runs on each and
// posts its slice; the backend merges them into the same stats:{email}:{date} row.
const METRIC_PAGES = [
  { key: 'connections',   url: 'https://www.linkedin.com/mynetwork/' },
  { key: 'invitations',   url: 'https://www.linkedin.com/mynetwork/invitation-manager/sent/' },
  { key: 'profile_views', url: 'https://www.linkedin.com/analytics/profile-views/' },
  { key: 'appearances',   url: 'https://www.linkedin.com/analytics/search-appearances/' },
  { key: 'premium',       url: 'https://www.linkedin.com/premium/sb/explore/' },
];

// ─── Storage helpers ────────────────────────────────────────────────
async function getPairing() {
  const s = await chrome.storage.local.get(['email', 'token', 'pairedAt', 'lastSyncAt', 'lastSyncStatus', 'lastSyncMessage']);
  return s;
}
async function setPairing(email, token) {
  await chrome.storage.local.set({ email, token, pairedAt: Date.now() });
}
async function recordSync(status, message) {
  await chrome.storage.local.set({
    lastSyncAt: Date.now(),
    lastSyncStatus: status,
    lastSyncMessage: String(message || '').slice(0, 300),
  });
}
async function log(level, msg, data) {
  const s = await chrome.storage.local.get('syncLog');
  const arr = s.syncLog || [];
  arr.push({ ts: new Date().toISOString(), level, msg, data: data || null });
  while (arr.length > MAX_LOG) arr.shift();
  await chrome.storage.local.set({ syncLog: arr });
}

// Report our version + pairing state to the server (validation that this build is installed/active).
async function reportCheckin(event) {
  try {
    const p = await getPairing();
    if (!p.token) return; // background check-in needs a token; content-pair covers the token-less case
    const ver = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '';
    await fetch(API_BASE + '/api/user/extension-checkin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.token },
      body: JSON.stringify({ version: ver, paired: true, event: event || 'heartbeat', last_sync_status: p.lastSyncStatus || null }),
    });
  } catch (e) { /* best-effort */ }
}

// Report sync progress/outcome to the server so the admin console can show real status.
// state: 'running' | 'done' | 'error'. Non-fatal on failure.
async function reportStatus(state, message, extra) {
  try {
    const p = await getPairing();
    if (!p.token) return;
    const ver = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '';
    await fetch(API_BASE + '/api/user/sync-report', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.token },
      body: JSON.stringify(Object.assign({ state, message: message || '', ext_version: ver }, extra || {})),
    });
  } catch (e) { /* offline / network — status reporting is best-effort */ }
}

// ─── Lifecycle ──────────────────────────────────────────────────────
const CHECKIN_ALARM = 'linalysisCheckin';
chrome.runtime.onInstalled.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { when: nextNineAM(), periodInMinutes: 24 * 60 });
  await chrome.alarms.create(SYNC_POLL_ALARM, { delayInMinutes: 1, periodInMinutes: 5 });
  await chrome.alarms.create(CHECKIN_ALARM, { delayInMinutes: 1, periodInMinutes: 180 });
  await log('info', 'installed');
  reportCheckin('installed');
});
chrome.runtime.onStartup.addListener(async () => {
  const a = await chrome.alarms.get(ALARM_NAME);
  if (!a) await chrome.alarms.create(ALARM_NAME, { when: nextNineAM(), periodInMinutes: 24 * 60 });
  const p = await chrome.alarms.get(SYNC_POLL_ALARM);
  if (!p) await chrome.alarms.create(SYNC_POLL_ALARM, { delayInMinutes: 1, periodInMinutes: 5 });
  const c = await chrome.alarms.get(CHECKIN_ALARM);
  if (!c) await chrome.alarms.create(CHECKIN_ALARM, { delayInMinutes: 1, periodInMinutes: 180 });
  reportCheckin('startup');
});

function nextNineAM() {
  const now = new Date();
  const t = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0, 0);
  if (t.getTime() <= now.getTime()) t.setDate(t.getDate() + 1);
  return t.getTime();
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === ALARM_NAME) await runSync('cron');
  if (alarm.name === SYNC_POLL_ALARM) await checkSyncRequest();
  if (alarm.name === CHECKIN_ALARM) await reportCheckin('heartbeat');
});

// Poll the API for an admin-triggered sync request. If one is pending, run a sync immediately.
async function checkSyncRequest() {
  const p = await getPairing();
  if (!p.token) return; // not paired yet — nothing to check
  try {
    const resp = await fetch(API_BASE + '/api/user/sync-request', {
      method: 'GET',
      headers: { 'Authorization': 'Bearer ' + p.token, 'Accept': 'application/json' },
    });
    if (!resp.ok) return;
    const j = await resp.json();
    if (j && j.pending) {
      await log('info', 'sync_request:received', { triggered_by: j.triggered_by, requested_at: j.requested_at });
      await runSync('admin-request');
    }
  } catch (e) { /* offline / network — skip this cycle */ }
}

// ─── Messages ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      if (msg && msg.type === 'linalysis-pair') {
        await setPairing(msg.email, msg.token);
        await log('info', 'paired', { email: msg.email });
        reportCheckin('paired');
        sendResponse({ ok: true, paired: true, email: msg.email });
        return;
      }
      if (msg && msg.type === 'linalysis-ssi-result') {
        const r = await postSSI(msg.data);
        sendResponse(r);
        return;
      }
      if (msg && msg.type === 'linalysis-metrics-result') {
        // Sent by content-metrics.js — either during the daily sync OR opportunistically when the
        // user browses one of their own analytics pages. Posts that page's slice; backend merges.
        const r = await postMetrics(msg.page, msg.data);
        sendResponse(r);
        return;
      }
      if (msg && msg.type === 'get-status') {
        const p = await getPairing();
        const s = await chrome.storage.local.get('syncLog');
        sendResponse(Object.assign({}, p, { log: s.syncLog || [] }));
        return;
      }
      if (msg && msg.type === 'sync-now') {
        const r = await runSync('manual');
        sendResponse(r);
        return;
      }
      sendResponse({ ok: false, error: 'unknown_message' });
    } catch (e) {
      sendResponse({ ok: false, error: String(e.message || e) });
    }
  })();
  return true;
});

// ─── Auto-pair from any open linalysis.net tab (radar-style: user never touches pairing) ─
// We MESSAGE the content script (content-pair.js) which already runs on linalysis.net with page
// access. This avoids chrome.scripting.executeScript, which fails with "Cannot access contents of
// the page. Extension manifest must request permission to access the respective host."
async function autoPairFromLinalysisTab() {
  const tabs = await chrome.tabs.query({ url: ['https://linalysis.net/*', 'https://www.linalysis.net/*'] });
  if (!tabs || tabs.length === 0) {
    await log('warn', 'auto_pair:no_tab');
    return { ok: false, step: 'no_linalysis_tab' };
  }
  // Try each linalysis tab until one pairs.
  let lastErr = null;
  for (const tab of tabs) {
    try {
      const r = await sendMessageAwait(tab.id, { type: 'linalysis-trigger-pair' });
      if (r && r.ok) {
        await setPairing(r.email, r.token);
        await log('info', 'auto_pair:ok', { email: r.email, via: 'content_script' });
        return r;
      }
      lastErr = r || { ok: false, step: 'no_response' };
    } catch (e) {
      lastErr = { ok: false, step: 'sendMessage', error: String(e.message || e) };
    }
  }
  await log('error', 'auto_pair:fail', lastErr || { error: 'no_response' });
  return lastErr || { ok: false, step: 'no_response' };
}

// Promisified chrome.tabs.sendMessage with lastError handling.
function sendMessageAwait(tabId, msg) {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        const le = chrome.runtime.lastError;
        if (le) { reject(new Error(le.message)); return; }
        resolve(resp);
      });
    } catch (e) { reject(e); }
  });
}

// ─── Sync ───────────────────────────────────────────────────────────
async function runSync(trigger) {
  await log('info', 'sync:start', { trigger });
  let p = await getPairing();
  if (!p.token) {
    const pair = await autoPairFromLinalysisTab();
    if (!pair.ok) {
      const msg = pair.step === 'no_linalysis_tab'
        ? 'Open linalysis.net and sign in — pairing needs a linalysis.net tab open.'
        : (pair.step + ': ' + (pair.error || 'unknown'));
      await recordSync('not_paired', msg);
      return { ok: false, error: 'not_paired', pair_detail: pair };
    }
    p = await getPairing();
  }
  // Tell the server we've started (admin console flips to "Syncing…").
  await reportStatus('running', 'Opening LinkedIn SSI and scraping (' + trigger + ')');

  // Open (or reuse) the SSI tab
  const existing = await chrome.tabs.query({ url: 'https://www.linkedin.com/sales/ssi*' });
  let tab, createdHere = false;
  if (existing && existing.length > 0) {
    tab = existing[0];
    await log('info', 'ssi:reused_tab', { tabId: tab.id });
  } else {
    tab = await chrome.tabs.create({ url: SSI_URL, active: false });
    createdHere = true;
    await log('info', 'ssi:opened_tab', { tabId: tab.id });
    // v0.1.6 — wait 12s for LinkedIn to render before triggering scrape. The content script
    // itself will also retry up to 3 times with 5s waits internally.
    await sleep(12000);
  }

  // SSI is BEST-EFFORT. LinkedIn redirects /sales/ssi to a non-www upsell host for accounts without
  // SSI access — that used to throw a host-permission error AND (via an early return) abort the whole
  // daily capture. Now: if the tab isn't actually on an SSI page, skip SSI honestly; and even a scrape
  // failure never aborts the growth + company metrics collected below.
  try {
    let finalUrl = '';
    try { const t = await chrome.tabs.get(tab.id); finalUrl = (t && t.url) || ''; } catch (_) {}
    if (finalUrl && !/\/sales\/ssi/.test(finalUrl)) {
      await recordSync('ssi_unavailable', 'LinkedIn redirected the SSI page (' + finalUrl.slice(0, 80) + ') — likely no SSI access on this account. Other metrics still collected.');
      await log('warn', 'ssi:redirected', { finalUrl: finalUrl.slice(0, 120) });
      await reportStatus('running', 'SSI unavailable (redirected) — collecting growth + company metrics.');
    } else {
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'linalysis-scrape-ssi' });
      } catch (e) {
        try {
          await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content-ssi.js'] });
          await sleep(2000);
          await chrome.tabs.sendMessage(tab.id, { type: 'linalysis-scrape-ssi' });
        } catch (e2) {
          await recordSync('ssi_skipped', 'SSI not captured this run (' + String(e2.message || e2) + ') — other metrics still collected.');
          await log('warn', 'sync:ssi_skipped', { error: String(e2.message || e2) });
          await reportStatus('running', 'SSI scrape skipped this run — collecting growth + company metrics.');
        }
      }
    }
  } catch (e) { await log('error', 'ssi:unexpected', { error: String(e.message || e) }); }

  if (createdHere) {
    // Give the content script 20 more seconds to complete its 3-attempt loop before closing.
    setTimeout(() => { try { chrome.tabs.remove(tab.id); } catch (_) {} }, 25000);
  }

  // Now collect the four growth metrics (Connections, Invitations, Views, Appearances). This runs
  // after SSI (SSI is best-effort above and never aborts this). Each page's content-metrics.js posts
  // its own slice, so a failure on one page never blocks the others.
  try { await collectMetrics(trigger); } catch (e) { await log('error', 'metrics:collect_failed', { error: String(e.message || e) }); }

  return { ok: true, triggered: trigger };
}

// Open each growth page in a hidden tab, trigger a scrape, then close it. Posting is event-driven:
// content-metrics.js also auto-runs on load and messages us, so metrics still land even if this
// orchestration loop is interrupted by the service worker being suspended.
async function collectMetrics(trigger) {
  const pages = METRIC_PAGES.slice();
  // Company admin analytics — only if we know the user's company ID (cached by content-metrics.js
  // when the admin last visited any /company/{id}/admin/* page). Skipped silently otherwise (no fake data).
  try {
    const cs = await chrome.storage.local.get('linalysis_company_id');
    const cid = cs && cs.linalysis_company_id;
    if (cid) {
      pages.push(
        { key: 'co_followers', url: 'https://www.linkedin.com/company/' + cid + '/admin/analytics/followers/' },
        { key: 'co_visitors',  url: 'https://www.linkedin.com/company/' + cid + '/admin/analytics/visitors/' },
        { key: 'co_updates',   url: 'https://www.linkedin.com/company/' + cid + '/admin/analytics/updates/' },
        { key: 'co_search',    url: 'https://www.linkedin.com/company/' + cid + '/admin/analytics/search-appearances/' }
      );
    } else { await log('info', 'company:skipped_no_id'); }
  } catch (e) {}
  await log('info', 'metrics:start', { trigger, pages: pages.length });
  for (const page of pages) {
    let tab = null;
    try {
      tab = await chrome.tabs.create({ url: page.url, active: false });
      await log('info', 'metrics:opened', { key: page.key, tabId: tab.id });
      await sleep(12000); // let LinkedIn render
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'linalysis-scrape-metrics' });
      } catch (e) {
        // Content script not injected yet (e.g. redirect) — inject and retry once.
        try {
          await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content-metrics.js'] });
          await sleep(2500);
          await chrome.tabs.sendMessage(tab.id, { type: 'linalysis-scrape-metrics' });
        } catch (e2) {
          await log('error', 'metrics:scrape_failed', { key: page.key, error: String(e2.message || e2) });
        }
      }
      // Invitations page self-scrolls its list to load a full day of sends — give it longer.
      await sleep(page.key === 'invitations' ? 26000 : 9000);
    } catch (e) {
      await log('error', 'metrics:page_failed', { key: page.key, error: String(e.message || e) });
    } finally {
      if (tab) { try { await chrome.tabs.remove(tab.id); } catch (_) {} }
    }
  }
  await log('info', 'metrics:done', { trigger });
}

// POST a single growth-page slice. `data` is already keyed with the CSV column names the ingest
// endpoint understands (Connections, Invitations, Views, All Appearances, …) plus a `_diag` blob.
async function postMetrics(page, data) {
  const p = await getPairing();
  if (!p.token || !p.email) return { ok: false, error: 'not_paired' };
  if (!data || typeof data !== 'object') return { ok: false, error: 'no_data' };
  const today = new Date().toISOString().slice(0, 10);
  const row = Object.assign({ 'Date': today }, data);
  const valueKeys = Object.keys(data).filter(k => k[0] !== '_');
  if (valueKeys.length === 0) {
    await log('warn', 'metrics:empty', { page, diag: data._diag || null });
    return { ok: false, error: 'no_values', page };
  }
  try {
    const resp = await fetch(API_BASE + '/api/ingest/linkedin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.token },
      body: JSON.stringify({ rows: [row] }),
    });
    if (!resp.ok) {
      const body = await resp.text();
      await log('error', 'metrics:http', { page, status: resp.status, body: body.slice(0, 160) });
      return { ok: false, error: 'api_error', http_status: resp.status };
    }
    const json = await resp.json();
    await log('info', 'metrics:ok', { page, keys: valueKeys, inserted: json.inserted, updated: json.updated });
    return { ok: true, page, captured: valueKeys, response: json };
  } catch (e) {
    await log('error', 'metrics:network', { page, error: String(e.message || e) });
    return { ok: false, error: 'network', message: String(e.message || e) };
  }
}

async function postSSI(data) {
  const p = await getPairing();
  if (!p.token || !p.email) return { ok: false, error: 'not_paired' };
  const today = new Date().toISOString().slice(0, 10);
  const row = Object.assign({ 'Date': today }, data);

  // How many of the 4 sub-scores did we actually capture?
  const subKeys = ['ssi_brand', 'ssi_prospecting', 'ssi_insights', 'ssi_relationships'];
  const capturedCount = subKeys.filter(k => data[k] != null).length;
  const diag = data._diag || null;

  try {
    const resp = await fetch(API_BASE + '/api/ingest/linkedin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + p.token },
      body: JSON.stringify({ rows: [row] }),
    });
    if (!resp.ok) {
      const errBody = await resp.text();
      await recordSync('api_error', 'HTTP ' + resp.status + ': ' + errBody.slice(0, 200));
      await log('error', 'ingest:http', { status: resp.status, body: errBody.slice(0, 200) });
      await reportStatus('error', 'Server rejected the data (HTTP ' + resp.status + ')', { captured_count: capturedCount, diag });
      return { ok: false, error: 'api_error', http_status: resp.status };
    }
    const json = await resp.json();
    if (capturedCount === 4) {
      await recordSync('ok', 'Captured all 4 SSI sub-scores');
      await log('info', 'ingest:ok', { inserted: json.inserted, updated: json.updated, captured: capturedCount });
      await reportStatus('done', 'Captured all 4 SSI sub-scores', { captured_count: capturedCount, diag });
    } else {
      // The row saved, but LinkedIn didn't yield a full SSI. Report as an error with the diagnostic
      // so the admin can see WHY (not signed in, page too slow, layout change, etc.).
      const why = diag && diag.has_signin ? 'looks like you were not signed in to LinkedIn'
                : diag && !diag.has_establish ? 'the SSI page did not show the sub-scores (layout change or still loading)'
                : 'LinkedIn returned only ' + capturedCount + ' of 4 sub-scores';
      await recordSync('partial', 'Only ' + capturedCount + '/4 sub-scores — ' + why);
      await log('warn', 'ingest:partial', { captured: capturedCount, diag });
      await reportStatus('error', 'Only ' + capturedCount + '/4 SSI sub-scores captured — ' + why, { captured_count: capturedCount, diag });
    }
    return { ok: true, response: json, captured_count: capturedCount };
  } catch (e) {
    await recordSync('network', String(e.message || e));
    await log('error', 'ingest:network', { error: String(e.message || e) });
    await reportStatus('error', 'Network error posting to Linalysis: ' + String(e.message || e), { captured_count: capturedCount, diag });
    return { ok: false, error: 'network', message: String(e.message || e) };
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
