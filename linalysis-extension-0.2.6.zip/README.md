# Linalysis Chrome extension (beta)

Reads your LinkedIn Social Selling Index (SSI) and metrics from your own browser and syncs them to your Linalysis account. Runs silently in the background — once per day.

## Why does it run locally instead of on our servers?

LinkedIn's `li_at` session cookie is **IP-bound**. If we used your cookie from a Cloudflare server, LinkedIn would immediately kill the session and log you out. The only safe way to collect your data is from your own machine while you're already signed into LinkedIn.

## Install (side-load — while we finish Web Store review)

1. Open `chrome://extensions` in Chrome or Edge.
2. Toggle **Developer mode** ON (top right).
3. Click **Load unpacked** and pick the `linalysis-extension` folder. Or unzip the downloaded `linalysis-extension.zip` first.
4. Pin the Linalysis puzzle-piece icon so you can find it.

## Use it

1. Sign into [linalysis.net](https://linalysis.net) — the extension pairs itself automatically (no forms).
2. Sign into LinkedIn in the same browser.
3. That's it. The extension will sync SSI once a day, in the background. Click the icon to see status or force a sync.

## What it captures (v0.1)

- SSI overall (0–100)
- SSI Industry percentile
- SSI Network percentile
- The 4 sub-scores: Establish Brand, Find Right People, Engage with Insights, Build Relationships

More metrics will be added as we tune the scrapers.

## Permissions we ask for and why

- `alarms` — schedule the daily sync
- `storage` — remember your paired email + API token locally (never leaves your device)
- `scripting`, `tabs` — open `linkedin.com/sales/ssi` in the background and read the SSI values
- `notifications` — tell you if a sync fails
- Host: `linkedin.com/*` — read the SSI page
- Host: `linalysis.net/*`, `api.linalysis.net/*` — pair with your account, upload data

## Version

0.1.0 — first release. Reports and bug feedback: alerts@linalysis.com
