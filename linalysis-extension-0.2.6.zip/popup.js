async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: 'get-status' });
  const emailEl = document.getElementById('email');
  if (s && s.email) {
    emailEl.textContent = s.email;
    emailEl.style.color = '#1d1d1f';
  } else {
    emailEl.innerHTML = '<span style="color:#d97706">Not paired</span> — open linalysis.net and sign in, then click Sync Now';
  }
  // Show LAST DATA actually captured — never a stalled attempt dressed up as success.
  const dataWhen = s && s.lastDataAt ? new Date(s.lastDataAt) : null;
  document.getElementById('lastSync').textContent = dataWhen ? relTime(dataWhen) : 'No data captured yet';
  const dataStaleH = dataWhen ? (Date.now() - dataWhen.getTime()) / 3600000 : Infinity;
  const status = s && s.lastSyncStatus;
  const statusEl = document.getElementById('lastSyncStatus');
  if (status === 'ok') {
    statusEl.textContent = '✓ ' + (s.lastSyncMessage || 'Synced cleanly');
    statusEl.style.color = '#16a34a';
  } else if (status === 'not_paired') {
    statusEl.textContent = '⚠ ' + (s.lastSyncMessage || 'Not paired');
    statusEl.style.color = '#d97706';
  } else if (status) {
    statusEl.textContent = '⚠ ' + status + ': ' + (s.lastSyncMessage || '');
    statusEl.style.color = '#d97706';
  } else {
    statusEl.textContent = '';
  }
  // Honesty override: if no real data landed in over a day, say so in red no matter what the last
  // attempt claimed. A recent "sync" that captured nothing must never look like success.
  if (dataStaleH > 26) {
    statusEl.textContent = '⚠ No data captured in over a day — the last sync attempt did not land data.';
    statusEl.style.color = '#cc1016';
  }
  renderLog(s && s.log);
}

function relTime(d) {
  const m = Math.round((Date.now() - d.getTime()) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + 'm ago';
  const h = Math.round(m / 60);
  if (h < 24) return h + 'h ago';
  return Math.round(h / 24) + 'd ago';
}

function renderLog(entries) {
  const el = document.getElementById('log');
  if (!el) return;
  if (!entries || entries.length === 0) {
    el.innerHTML = '<div style="color:#9ca3af;font-size:11px">No sync activity yet.</div>';
    return;
  }
  const rows = entries.slice(-8).reverse().map(e => {
    const color = e.level === 'error' ? '#cc1016' : (e.level === 'warn' ? '#d97706' : '#374151');
    const time = (e.ts || '').slice(11, 19);
    const data = e.data ? ' <span style="color:#6b7280">' + escapeHtml(JSON.stringify(e.data).slice(0, 90)) + '</span>' : '';
    return '<div style="margin-bottom:3px"><span style="color:#9ca3af">' + time + '</span> <strong style="color:' + color + '">' + escapeHtml(e.msg) + '</strong>' + data + '</div>';
  }).join('');
  el.innerHTML = '<details style="margin-top:10px;border-top:1px solid #f3f4f6;padding-top:8px"><summary style="cursor:pointer;font-size:11px;color:#0a66c2">Sync log (' + entries.length + ')</summary><div style="margin-top:6px;font-family:ui-monospace,Consolas,monospace;font-size:10px;line-height:1.4;max-height:200px;overflow-y:auto;background:#f9fafb;padding:6px;border-radius:4px">' + rows + '</div></details>';
}

function escapeHtml(s) {
  return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

document.getElementById('syncNow').addEventListener('click', async () => {
  const btn = document.getElementById('syncNow');
  const statusEl = document.getElementById('lastSyncStatus');
  btn.disabled = true; btn.textContent = 'Syncing…';
  statusEl.textContent = 'Pairing + opening LinkedIn…';
  statusEl.style.color = '#6b7280';
  try {
    const r = await chrome.runtime.sendMessage({ type: 'sync-now' });
    if (r && r.ok) {
      statusEl.textContent = '✓ Sync started — result in a few seconds';
      statusEl.style.color = '#16a34a';
    } else if (r && r.error === 'not_paired') {
      statusEl.textContent = '⚠ Not paired. Open linalysis.net (signed in), then Sync Now again.';
      statusEl.style.color = '#d97706';
    } else if (r) {
      statusEl.textContent = '⚠ ' + (r.error || 'sync failed') + ': ' + (r.message || '');
      statusEl.style.color = '#cc1016';
    }
    setTimeout(refresh, 10000);
  } finally {
    setTimeout(() => { btn.disabled = false; btn.textContent = 'Sync now'; }, 4000);
  }
});

// Show the installed extension version so it's obvious which build is running.
try {
  const v = chrome.runtime.getManifest().version;
  const vEl = document.getElementById('version');
  if (vEl) vEl.textContent = 'Linalysis extension v' + v;
} catch (e) { /* non-fatal */ }

refresh();
