// Linalysis content-pair.js
// Runs on linalysis.net. Silently pairs the extension with the signed-in user by:
//   1. Announcing itself to the page (sentinel attribute + postMessage)
//   2. Reading the current email from localStorage
//   3. Minting an API bearer token via POST /api/account/token
//   4. Handing (email, token) to the background service worker
// Also handles a "pair" postMessage from the page so troubleshooting.html can trigger a manual pair.

(function () {
  // ── 1. Sentinel — makes the extension detectable from the page ─────
  try {
    document.documentElement.setAttribute('data-linalysis-ext', 'installed');
    document.documentElement.setAttribute('data-linalysis-ext-version', chrome.runtime.getManifest().version);
    document.documentElement.setAttribute('data-linalysis-ext-id', chrome.runtime.id);
  } catch (e) {}

  // Reply to page-side probes: window.postMessage({source:'linalysis-page', type:'ping'})
  window.addEventListener('message', function (e) {
    if (!e || !e.data || e.data.source !== 'linalysis-page') return;
    if (e.data.type === 'ping') {
      window.postMessage({ source: 'linalysis-ext', type: 'pong', version: chrome.runtime.getManifest().version, extId: chrome.runtime.id }, location.origin);
    }
    if (e.data.type === 'request-li_at') {
      // No-op — we don't store or expose li_at from the extension. Kept for older probes.
      window.postMessage({ source: 'linalysis-ext', type: 'li_at', li_at: null }, location.origin);
    }
    if (e.data.type === 'manual-pair') {
      tryPair(true);
    }
  });

  // Let the background service worker trigger a pair THROUGH this content script (which already has
  // page + host access). This avoids chrome.scripting.executeScript, which fails with
  // "Cannot access contents of the page" on some Chrome/host-permission configurations.
  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === 'linalysis-trigger-pair') {
      tryPair(true).then(function (state) { sendResponse(state); });
      return true; // async response
    }
    return false;
  });

  // ── Version check-in — report our version to the server using the page's own session cookie.
  // This is the SERVER-SIDE validation that this exact version is installed and active. It works
  // even if background pairing is failing, because it uses the linalysis.net session, not a token.
  (function checkin() {
    try {
      var ver = chrome.runtime.getManifest().version;
      var email = null; try { email = localStorage.getItem('linalysis_user_email'); } catch (e) {}
      if (!email) return; // not signed in on this tab — nothing to attribute the check-in to
      var paired = false; try { paired = !!localStorage.getItem('linalysis_ext_token'); } catch (e) {}
      fetch('https://api.linalysis.net/api/user/extension-checkin', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ version: ver, paired: paired, event: 'page' }),
      }).catch(function () {});
    } catch (e) {}
  })();

  // ── 2. Auto-pair — retry up to 3 times because api.js's /auth/me is async
  tryPair(false);
  setTimeout(function () { tryPair(false); }, 2000);
  setTimeout(function () { tryPair(false); }, 5000);

  async function tryPair(force) {
    var email = null;
    try { email = localStorage.getItem('linalysis_user_email'); } catch (e) {}
    if (!email) {
      var s1 = { ok: false, step: 'read_email', error: 'no_email_in_localstorage', hint: 'User not signed in yet' };
      report(s1); return s1;
    }

    var token = null;
    if (!force) {
      try { token = localStorage.getItem('linalysis_ext_token'); } catch (e) {}
    }

    if (!token) {
      try {
        var r = await fetch('https://api.linalysis.net/api/account/token', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: 'chrome-extension' }),
        });
        if (!r.ok) {
          var body = await r.text();
          var s2 = { ok: false, step: 'mint_token', http_status: r.status, error: body.slice(0, 200) };
          report(s2); return s2;
        }
        var j = await r.json();
        token = j.token || j.value;
        try { localStorage.setItem('linalysis_ext_token', token); } catch (e) {}
      } catch (e) {
        var s3 = { ok: false, step: 'mint_token', error: 'network', message: String(e.message || e) };
        report(s3); return s3;
      }
    }

    if (!token) {
      var s4 = { ok: false, step: 'mint_token', error: 'empty_token' };
      report(s4); return s4;
    }

    // Send pairing to background service worker. Resolve once the SW acks.
    return await new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'linalysis-pair', email: email, token: token }, function (resp) {
          var lastErr = chrome.runtime.lastError;
          if (lastErr) {
            var se = { ok: false, step: 'sendMessage', error: lastErr.message };
            report(se); resolve(se);
          } else {
            var so = { ok: true, paired: true, email: email, token: token };
            report(so); resolve(so);
          }
        });
      } catch (e) {
        var sx = { ok: false, step: 'sendMessage', error: String(e.message || e) };
        report(sx); resolve(sx);
      }
    });
  }

  // Surface pairing state on the page so users can see what's happening
  function report(state) {
    try {
      window.postMessage({ source: 'linalysis-ext', type: 'pair-report', state: state }, location.origin);
      // Also stash on the html element so troubleshooting.html can read it synchronously
      document.documentElement.setAttribute('data-linalysis-ext-pair', JSON.stringify(state).slice(0, 500));
    } catch (e) {}
  }
})();
