// Linalysis content script for LinkedIn "growth" metrics — v0.2.0
// Runs on: /mynetwork/*  (Connections + Sent invitations), /analytics/*  and /me/profile-views*
//          (Profile views + Search/Profile appearances).
//
// Mirrors content-ssi.js: waits for the page to settle, scrapes the fields relevant to the current
// URL, and sends { type:'linalysis-metrics-result', page, data } to the background worker, which
// POSTs to /api/ingest/linkedin. Also responds to an explicit { type:'linalysis-scrape-metrics' }
// request so the background worker can pull on demand during the daily sync.
//
// MULTILINGUAL by requirement (users are EN / DE / FR — see linalysis_ssi_multilingual memory):
// every label is matched across EN/DE/FR (+ ES/IT/PT/NL where cheap), and every number is parsed
// with parseCount()/parseNum() so thousands separators (29,629 / 29.629 / 29 629) and comma
// decimals (44,3 %) all normalise correctly.

(function () {
  const READY_DELAY_MS = 5000;
  setTimeout(scrapeAndSend, READY_DELAY_MS);

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'linalysis-scrape-metrics') {
      scrapeAndSend().then(sendResponse);
      return true; // async
    }
    return false;
  });

  function currentPage() {
    const p = location.pathname;
    if (p.includes('invitation-manager')) return 'invitations';
    if (p.startsWith('/mynetwork'))        return 'connections';
    if (p.includes('search-appearances'))  return 'appearances';
    if (p.includes('profile-views'))       return 'profile_views';
    if (p.includes('/premium/'))           return 'premium';
    return null;
  }

  async function scrapeAndSend() {
    const page = currentPage();
    if (!page) return { ok: false, error: 'unrecognized_page', path: location.pathname };
    try {
      let data = null;
      // Up to 3 attempts, 5s apart — break as soon as we captured the page's primary number.
      for (let attempt = 1; attempt <= 3; attempt++) {
        data = await scrapeForPage(page, attempt);
        if (hasPrimary(page, data)) break;
        if (attempt < 3) await sleep(5000);
      }
      const r = await chrome.runtime.sendMessage({ type: 'linalysis-metrics-result', page, data });
      return { ok: true, page, data, response: r };
    } catch (e) {
      return { ok: false, page, error: String(e.message || e) };
    }
  }

  // Did we get the field that makes this page worth posting?
  function hasPrimary(page, d) {
    if (!d) return false;
    if (page === 'connections')   return d['Connections'] != null;
    if (page === 'invitations')   return d['Invitations'] != null;
    if (page === 'profile_views') return d['Views'] != null;
    if (page === 'appearances')   return d['All Appearances'] != null || d['Search Appearances'] != null;
    if (page === 'premium')       return d['InMail Credits'] != null;
    return false;
  }

  async function scrapeForPage(page, attempt) {
    if (page === 'connections')   return scrapeConnections(attempt);
    if (page === 'invitations')   return await scrapeInvitations(attempt);
    if (page === 'profile_views') return scrapeProfileViews(attempt);
    if (page === 'appearances')   return scrapeAppearances(attempt);
    if (page === 'premium')       return await scrapePremium(attempt);
    return {};
  }

  // ── 1) CONNECTIONS  (/mynetwork/ → /mynetwork/grow/) ────────────────
  // Primary: the "Connections" entry in the "Manage my network" rail links to the connections list;
  // its text carries the count. This is language-independent (matches on the href). Fallback: match a
  // localized "Connections" label followed/preceded by a number in the page text.
  function scrapeConnections(attempt) {
    const out = {};
    let n = null;
    try {
      const a = document.querySelector(
        'a[href*="/mynetwork/invite-connect/connections"], a[href^="/mynetwork/invite-connect/connections"]'
      );
      if (a) n = firstCountIn(a.innerText || a.textContent || '');
    } catch (e) {}
    if (n == null) {
      const text = document.body ? document.body.innerText : '';
      n = countNearLabel(text, ['Connections', 'Verbindungen', 'Kontakte', 'Relations', 'Contatti', 'Contactos', 'Conexões', 'Connecties']);
    }
    if (n != null) out['Connections'] = n;
    out['_diag'] = baseDiag('connections', attempt);
    return out;
  }

  // ── 2) SENT INVITATIONS  (/mynetwork/invitation-manager/sent/) ──────
  // Captures: pending backlog (People + Pages pills) AND — the important one for weekly-credit ROI —
  // how many invitations were sent in the last 24h / 7d, read from each row's "Sent X ago" stamp.
  // The pending total is NOT weekly usage; LinkedIn's ~100/week limit is a rolling send count, so the
  // dashboard sums the daily "Invitations Sent 24h" across 7 days to get true credit utilisation.
  async function scrapeInvitations(attempt) {
    const out = {};
    const txt0 = document.body ? document.body.innerText : '';
    const people = parenCount(txt0, ['People', 'Personen', 'Personnes', 'Personas', 'Persone', 'Pessoas', 'Personen']);
    const pages  = parenCount(txt0, ['Pages', 'Seiten', 'Páginas', 'Pagine', "Pagina's"]);
    if (people != null) out['Invitations'] = people;             // pending backlog (people)
    if (pages  != null) out['Invitations Pages'] = pages;        // pending backlog (pages)

    // Load a bit more of the list so a full day's sends are in the DOM, then bucket by age.
    await loadMoreSentList();
    const buckets = countSentByAge();
    if (buckets) {
      out['Invitations Sent 24h'] = buckets.d1;
      out['Invitations Sent 7d']  = buckets.d7;   // best-effort — only accurate if the week fit on screen
      out['_sent_rows_seen']      = buckets.rows;
      out['_sent_oldest_days']    = buckets.maxAge;
    }
    out['_diag'] = Object.assign(baseDiag('invitations', attempt), {
      pending_people: people, pending_pages: pages,
      sent_rows_seen: buckets ? buckets.rows : 0,
      sent_oldest_days: buckets ? buckets.maxAge : null,
      full_week_loaded: buckets ? (buckets.maxAge != null && buckets.maxAge >= 7) : false,
    });
    return out;
  }

  // Scroll the invitation list a bounded number of times to pull in more rows. In a real signed-in
  // browser this triggers LinkedIn's lazy-load; we stop early once a row older than 8 days appears
  // (we've covered the whole rolling week) or the row count stops growing.
  async function loadMoreSentList() {
    const scroller = document.querySelector('main') || document.scrollingElement || document.body;
    let last = -1, stable = 0;
    for (let i = 0; i < 25; i++) {
      try {
        const btn = [...document.querySelectorAll('button')]
          .find(b => /show more|see more|mehr anzeigen|mehr ergebnisse|voir plus|plus de résultats/i.test(b.textContent || ''));
        if (btn) btn.click();
        if (scroller) scroller.scrollTop = scroller.scrollHeight;
        window.scrollTo(0, document.body.scrollHeight);
      } catch (e) {}
      await sleep(800);
      const b = countSentByAge();
      const rows = b ? b.rows : 0;
      if (b && b.maxAge != null && b.maxAge > 8) break; // whole week is loaded
      if (rows === last) { stable++; if (stable >= 4) break; } else stable = 0;
      last = rows;
    }
  }

  // Count sent-invitation rows by age from their "Sent X <unit> ago" stamps (EN/DE/FR). Dedupes by
  // "<name>|<stamp>" so nested DOM nodes don't double-count.
  function countSentByAge() {
    const re = /(?:Sent|Gesendet|Envoy[ée])\s*(?:vor\s*)?(?:il y a\s*)?(\d+)\s*(second|Sekunde|seconde|minute|Minute|hour|Stunde|heure|day|Tag|jour|week|Woche|semaine|month|Monat|mois)s?\s*(?:ago|zuvor)?/i;
    const seen = new Map();
    const nodes = document.querySelectorAll('li, div');
    for (const el of nodes) {
      const t = el.innerText || '';
      if (t.length > 320) continue;
      const m = t.match(re);
      if (!m) continue;
      const name = (t.split('\n')[0] || '').slice(0, 60).trim();
      const key = name + '|' + m[0];
      if (!seen.has(key)) seen.set(key, ageInDays(Number(m[1]), m[2]));
    }
    if (seen.size === 0) return null;
    let d1 = 0, d7 = 0, maxAge = 0;
    for (const d of seen.values()) {
      if (d <= 1) d1++;
      if (d <= 7) d7++;
      if (d > maxAge) maxAge = d;
    }
    return { rows: seen.size, d1, d7, maxAge };
  }

  function ageInDays(n, unit) {
    unit = String(unit).toLowerCase();
    if (/second|sekunde|seconde|minute|hour|stunde|heure/.test(unit)) return 0;
    if (/day|tag|jour/.test(unit))     return n;
    if (/week|woche|semaine/.test(unit)) return n * 7;
    if (/month|monat|mois/.test(unit)) return n * 30;
    return 999;
  }

  // ── 3) PROFILE VIEWS  (/analytics/profile-views/ → /me/profile-views) ─
  // Layout: big number ABOVE the "Profile viewers" label, plus a "▲ 22% vs prior …" delta.
  function scrapeProfileViews(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const labels = ['profile viewers', 'profile views', 'Profilbesucher', 'Profil-Anzeigen', 'Profilaufrufe',
                    'vues du profil', 'visites du profil', 'visualizzazioni del profilo', 'vistas de perfil'];
    const n = countBeforeLabel(text, labels);
    if (n != null) out['Views'] = n;
    const chg = changeNear(text, labels);
    if (chg != null) out['Profile Views Change'] = chg;   // e.g. "+22%" / "-8%"
    out['_diag'] = baseDiag('profile_views', attempt);
    return out;
  }

  // ── 4) SEARCH / PROFILE APPEARANCES  (/analytics/search-appearances/) ─
  // Two headline numbers ("All appearances" + "Search appearances"), the "Where you appeared"
  // breakdown, and the week range LinkedIn reports for.
  function scrapeAppearances(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const all = countBeforeLabel(text, ['all appearances', 'alle Anzeigen', 'alle Erscheinungen', 'toutes les apparitions', 'todas las apariciones', 'tutte le comparse']);
    const search = countBeforeLabel(text, ['search appearances', 'Suchanzeigen', 'Sucherscheinungen', "apparitions dans les recherches", 'apariciones en búsquedas', 'comparse nelle ricerche']);
    if (all != null)    out['All Appearances'] = all;
    if (search != null) out['Search Appearances'] = search;

    // "Where you appeared" breakdown — capture label/percent pairs (Search 44.3%, Posts 34.5%, …).
    try {
      const sources = [];
      const re = /([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .]{2,34}?)\s*[·:\-–]\s*(\d{1,3}(?:[.,]\d)?)\s*%/g;
      let m, guard = 0;
      while ((m = re.exec(text)) && guard++ < 12) {
        const label = m[1].trim();
        const pct = parseNum(m[2]);
        if (!isNaN(pct) && pct >= 0 && pct <= 100 && label.length >= 3) sources.push({ label, pct });
      }
      if (sources.length) out['Appearance Sources'] = sources.slice(0, 6);
    } catch (e) {}

    // Week range LinkedIn reports for (e.g. "July 14 – July 20"). Best-effort, EN/DE/FR month names.
    try {
      const wk = text.match(/([A-Za-zÀ-ÿ]{3,12}\.?\s*\d{1,2})\s*[–—-]\s*((?:[A-Za-zÀ-ÿ]{3,12}\.?\s*)?\d{1,2})/);
      if (wk) out['Appearances Week'] = (wk[1] + ' – ' + wk[2]).replace(/\s+/g, ' ').trim();
    } catch (e) {}

    out['_diag'] = baseDiag('appearances', attempt);
    return out;
  }

  // ── 5) INMAIL / PREMIUM CREDITS  (/premium/sb/explore/) ─────────────
  // LinkedIn only exposes the CURRENT balance: the InMail card shows "Credits available: N".
  // We scrape that real number (plus the plan name + renewal date from the Plan Details panel).
  // The card is collapsed by default, so if the number isn't already in the DOM we expand it first.
  async function scrapePremium(attempt) {
    const out = {};
    let credits = findInMailCredits();
    if (credits == null) { expandInMailCard(); await sleep(1800); credits = findInMailCredits(); }
    if (credits == null) { expandInMailCard(); await sleep(1800); credits = findInMailCredits(); }
    if (credits != null) out['InMail Credits'] = credits;

    const text = (document.body ? document.body.innerText : '') + '\n' + (document.body ? document.body.textContent : '');
    const plan = findPlan(text);
    if (plan) out['Premium Plan'] = plan;
    const ren = text.match(/Renews?\s+on\s+([A-Za-zÀ-ÿ]+\.?\s+\d{1,2},?\s+\d{4})/i);
    if (ren) out['Premium Renews'] = ren[1].replace(/\s+/g, ' ').trim();

    out['_diag'] = Object.assign(baseDiag('premium', attempt), { credits_found: credits, plan: plan || null });
    return out;
  }

  // Search the whole DOM (textContent catches collapsed/hidden accordion content that innerText skips).
  function findInMailCredits() {
    const scan = function (str) {
      if (!str) return null;
      const m = str.match(/Credits?\s*available\s*[:\-–]?\s*(\d[\d.,  ']*)/i);
      return m ? parseCount(m[1]) : null;
    };
    const a = scan(document.body ? document.body.textContent : '');
    if (a != null) return a;
    return scan(document.body ? document.body.innerText : '');
  }

  // Click the InMail card header to expand it (only needed if the balance isn't already in the DOM).
  function expandInMailCard() {
    try {
      const els = document.querySelectorAll('button, [role="button"], [aria-expanded]');
      for (const el of els) {
        const t = (el.getAttribute('aria-label') || el.innerText || el.textContent || '').trim();
        if (/^InMail\b/i.test(t) && t.length < 60) { el.click(); return true; }
      }
    } catch (e) {}
    return false;
  }

  // Plan name from the Plan Details panel — match a known plan, else the line after "Plan Details".
  function findPlan(text) {
    const known = ['Sales Navigator Advanced Plus', 'Sales Navigator Advanced', 'Sales Navigator Core',
                   'Recruiter Lite', 'Recruiter Professional', 'Recruiter',
                   'Premium Career', 'Premium Business', 'Career', 'Business'];
    for (const k of known) { if (new RegExp(escapeRe(k), 'i').test(text)) return k; }
    const m = text.match(/Plan Details\s*\n?\s*([A-Za-z][A-Za-z .]{3,40})/i);
    return m ? m[1].trim() : null;
  }

  // ── Shared helpers ──────────────────────────────────────────────────
  function baseDiag(page, attempt) {
    const text = document.body ? document.body.innerText : '';
    return {
      page, attempt: attempt || 1, url: location.href,
      title: (document.title || '').slice(0, 120),
      text_len: text.length,
      lang: (document.documentElement.getAttribute('lang') || navigator.language || '').slice(0, 5).toLowerCase() || null,
      has_signin: /sign in|log in|anmelden|se connecter/i.test(text.slice(0, 500)),
      first_300: text.slice(0, 300),
    };
  }

  function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  // Parse an integer count, stripping thousands separators (',', '.', ' ', nbsp, "'"): "29,629"→29629,
  // "29.629"→29629, "29 629"→29629. For counts every separator is a grouping separator, so we drop them all.
  function parseCount(s) {
    if (s == null) return null;
    const digits = String(s).replace(/[^\d]/g, '');
    if (!digits) return null;
    const n = parseInt(digits, 10);
    return Number.isNaN(n) ? null : n;
  }

  // Parse a decimal that may use a comma decimal separator: "44,3"→44.3, "44.3"→44.3.
  function parseNum(s) {
    if (s == null) return NaN;
    s = String(s).trim();
    if (s.indexOf(',') > -1 && s.indexOf('.') > -1) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (s.indexOf(',') > -1) {
      s = s.replace(',', '.');
    }
    return parseFloat(s);
  }

  // First count found inside a short string (e.g. an anchor's text).
  function firstCountIn(s) {
    const m = String(s).match(/(\d[\d.,  ']*)/);
    return m ? parseCount(m[1]) : null;
  }

  // A count adjacent to any of the localized labels (number before OR after, same line, no other digit
  // in the gap so we don't grab a neighbouring row's number).
  function countNearLabel(text, labels) {
    const num = "(\\d[\\d.,\\u00a0 ']*)";
    for (const label of labels) {
      const kw = escapeRe(label);
      let m = text.match(new RegExp(kw + "[^\\n0-9]{0,20}?" + num, 'i'));   // label → number
      if (!m) m = text.match(new RegExp(num + "[^\\n0-9]{0,20}?" + kw, 'i')); // number → label
      if (m) { const n = parseCount(m[1]); if (n != null) return n; }
    }
    return null;
  }

  // A count that appears immediately BEFORE a label (analytics headline layout: "1,137\nProfile viewers").
  function countBeforeLabel(text, labels) {
    const num = "(\\d[\\d.,\\u00a0 ']*)";
    for (const label of labels) {
      const kw = escapeRe(label);
      const m = text.match(new RegExp(num + "\\s*\\n?\\s*" + kw, 'i'));
      if (m) { const n = parseCount(m[1]); if (n != null) return n; }
      // also tolerate number AFTER label
      const m2 = text.match(new RegExp(kw + "[^\\n0-9]{0,20}?" + num, 'i'));
      if (m2) { const n2 = parseCount(m2[1]); if (n2 != null) return n2; }
    }
    return null;
  }

  // A signed percentage change near a label, e.g. "▲ 22% vs prior 7 days" → "+22%", "▼ 8%" → "-8%".
  function changeNear(text, labels) {
    for (const label of labels) {
      const kw = escapeRe(label);
      // Search a window after the label for an up/down marker + percent.
      const m = text.match(new RegExp(kw + "[\\s\\S]{0,80}?([▲▼↑↓+\\-]|up|down|increase|decrease|hausse|baisse|mehr|weniger)?\\s*(\\d{1,3})\\s*%", 'i'));
      if (m) {
        const dir = (m[1] || '').toLowerCase();
        const down = /[▼↓-]|down|decrease|baisse|weniger/.test(dir);
        return (down ? '-' : '+') + m[2] + '%';
      }
    }
    return null;
  }

  // "(711)" next to a People/Pages tab label → 711.
  function parenCount(text, labels) {
    for (const label of labels) {
      const kw = escapeRe(label);
      const m = text.match(new RegExp(kw + "\\s*\\((\\d[\\d.,\\u00a0 ']*)\\)", 'i'));
      if (m) { const n = parseCount(m[1]); if (n != null) return n; }
    }
    return null;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
})();
