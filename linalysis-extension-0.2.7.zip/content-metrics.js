// Linalysis content script for LinkedIn "growth" metrics — v0.2.0
// Runs on: /mynetwork/*  (Connections + Sent invitations), /analytics/*  and /me/profile-views*
//          (Profile views + Search/Profile appearances).
//
// Mirrors content-ssi.js: waits for the page to settle, scrapes the fields relevant to the current
// URL, and sends { type:'linalysis-metrics-result', page, data } to the background worker, which
// POSTs to /api/ingest/linkedin. Also responds to an explicit { type:'linalysis-scrape-metrics' }
// request so the background worker can pull on demand during the daily sync.
//
// MULTILINGUAL by requirement (users are EN / DE / FR — see linalysis_ssi_multilingual memory):
// every label is matched across EN/DE/FR (+ ES/IT/PT/NL where cheap), and every number is parsed
// with parseCount()/parseNum() so thousands separators (29,629 / 29.629 / 29 629) and comma
// decimals (44,3 %) all normalise correctly.

(function () {
  const READY_DELAY_MS = 5000;

  // Cache the company ID whenever the admin is on any /company/{id}/admin/* page, so the daily
  // sync can build the analytics URLs without hardcoding it (works for any admin user).
  try {
    const cm = location.pathname.match(/\/company\/(\d+)\/admin/);
    if (cm && chrome && chrome.storage) chrome.storage.local.set({ linalysis_company_id: cm[1] });
  } catch (e) {}

  setTimeout(scrapeAndSend, READY_DELAY_MS);

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'linalysis-scrape-metrics') {
      scrapeAndSend().then(sendResponse);
      return true; // async
    }
    return false;
  });

  function currentPage() {
    const p = location.pathname;
    if (/^\/company\/\d+\/admin\/analytics\/followers/.test(p))          return 'co_followers';
    if (/^\/company\/\d+\/admin\/analytics\/visitors/.test(p))           return 'co_visitors';
    if (/^\/company\/\d+\/admin\/analytics\/updates/.test(p))            return 'co_updates';
    if (/^\/company\/\d+\/admin\/analytics\/search-appearances/.test(p)) return 'co_search';
    if (p.includes('invitation-manager')) return 'invitations';
    if (p.startsWith('/mynetwork'))        return 'connections';
    if (p.includes('search-appearances'))  return 'appearances';
    if (p.includes('profile-views'))       return 'profile_views';
    if (p.includes('/premium/'))           return 'premium';
    return null;
  }

  async function scrapeAndSend() {
    const page = currentPage();
    if (!page) return { ok: false, error: 'unrecognized_page', path: location.pathname };
    try {
      let data = null;
      // Up to 3 attempts, 5s apart — break as soon as we captured the page's primary number.
      for (let attempt = 1; attempt <= 3; attempt++) {
        data = await scrapeForPage(page, attempt);
        if (hasPrimary(page, data)) break;
        if (attempt < 3) await sleep(5000);
      }
      // FAILURE SAMPLE. When the primary field did not resolve, ship a slice of the page's own main
      // content so the next fix can be made from the daily report instead of needing a live browser
      // session on the affected user's machine. Only on failure, and only the metric region — this
      // is diagnostic text, never stored as data.
      if (!hasPrimary(page, data)) {
        if (!data) data = {};
        data._diag = Object.assign(data._diag || {}, { sample: pageSample() });
      }
      const r = await chrome.runtime.sendMessage({ type: 'linalysis-metrics-result', page, data });
      return { ok: true, page, data, response: r };
    } catch (e) {
      return { ok: false, page, error: String(e.message || e) };
    }
  }

  // Did we get the field that makes this page worth posting?
  function hasPrimary(page, d) {
    if (!d) return false;
    if (page === 'connections')   return d['Connections'] != null;
    if (page === 'invitations')   return d['Invitations'] != null;
    if (page === 'profile_views') return d['Views'] != null;
    if (page === 'appearances')   return d['All Appearances'] != null || d['Search Appearances'] != null;
    if (page === 'premium')       return d['InMail Credits'] != null;
    if (page === 'co_followers')  return d['Company Followers'] != null;
    if (page === 'co_visitors')   return d['Company Unique Visitors'] != null;
    if (page === 'co_updates')    return d['Company Post Impressions'] != null;
    if (page === 'co_search')     return d['Company Search Appearances'] != null;
    return false;
  }

  async function scrapeForPage(page, attempt) {
    if (page === 'connections')   return scrapeConnections(attempt);
    if (page === 'invitations')   return await scrapeInvitations(attempt);
    if (page === 'profile_views') return scrapeProfileViews(attempt);
    if (page === 'appearances')   return scrapeAppearances(attempt);
    if (page === 'premium')       return await scrapePremium(attempt);
    if (page === 'co_followers')  return scrapeCoFollowers(attempt);
    if (page === 'co_visitors')   return scrapeCoVisitors(attempt);
    if (page === 'co_updates')    return scrapeCoUpdates(attempt);
    if (page === 'co_search')     return scrapeCoSearch(attempt);
    return {};
  }

  // ── 1) CONNECTIONS  (/mynetwork/ → /mynetwork/grow/) ────────────────
  // Primary: the "Connections" entry in the "Manage my network" rail links to the connections list;
  // its text carries the count. This is language-independent (matches on the href). Fallback: match a
  // localized "Connections" label followed/preceded by a number in the page text.
  function scrapeConnections(attempt) {
    const out = {};
    let n = null;
    try {
      const a = document.querySelector(
        'a[href*="/mynetwork/invite-connect/connections"], a[href^="/mynetwork/invite-connect/connections"]'
      );
      if (a) n = firstCountIn(a.innerText || a.textContent || '');
    } catch (e) {}
    if (n == null) {
      const text = document.body ? document.body.innerText : '';
      n = countNearLabel(text, ['Connections', 'Verbindungen', 'Kontakte', 'Relations', 'Contatti', 'Contactos', 'Conexões', 'Connecties']);
    }
    if (n != null) out['Connections'] = n;
    out['_diag'] = baseDiag('connections', attempt);
    return out;
  }

  // ── 2) SENT INVITATIONS  (/mynetwork/invitation-manager/sent/) ──────
  // Captures: pending backlog (People + Pages pills) AND — the important one for weekly-credit ROI —
  // how many invitations were sent in the last 24h / 7d, read from each row's "Sent X ago" stamp.
  // The pending total is NOT weekly usage; LinkedIn's ~100/week limit is a rolling send count, so the
  // dashboard sums the daily "Invitations Sent 24h" across 7 days to get true credit utilisation.
  async function scrapeInvitations(attempt) {
    const out = {};
    const txt0 = document.body ? document.body.innerText : '';
    const people = parenCount(txt0, ['People', 'Personen', 'Personnes', 'Personas', 'Persone', 'Pessoas', 'Personen']);
    const pages  = parenCount(txt0, ['Pages', 'Seiten', 'Páginas', 'Pagine', "Pagina's"]);
    if (people != null) out['Invitations'] = people;             // pending backlog (people)
    if (pages  != null) out['Invitations Pages'] = pages;        // pending backlog (pages)

    // Load a bit more of the list so a full day's sends are in the DOM, then bucket by age.
    await loadMoreSentList();
    const buckets = countSentByAge();
    if (buckets) {
      out['Invitations Sent 24h'] = buckets.d1;
      out['Invitations Sent 7d']  = buckets.d7;   // best-effort — only accurate if the week fit on screen
      out['_sent_rows_seen']      = buckets.rows;
      out['_sent_oldest_days']    = buckets.maxAge;
    }
    out['_diag'] = Object.assign(baseDiag('invitations', attempt), {
      pending_people: people, pending_pages: pages,
      sent_rows_seen: buckets ? buckets.rows : 0,
      sent_oldest_days: buckets ? buckets.maxAge : null,
      full_week_loaded: buckets ? (buckets.maxAge != null && buckets.maxAge >= 7) : false,
    });
    return out;
  }

  // Scroll the invitation list a bounded number of times to pull in more rows. In a real signed-in
  // browser this triggers LinkedIn's lazy-load; we stop early once a row older than 8 days appears
  // (we've covered the whole rolling week) or the row count stops growing.
  async function loadMoreSentList() {
    const scroller = document.querySelector('main') || document.scrollingElement || document.body;
    let last = -1, stable = 0;
    for (let i = 0; i < 25; i++) {
      try {
        const btn = [...document.querySelectorAll('button')]
          .find(b => /show more|see more|mehr anzeigen|mehr ergebnisse|voir plus|plus de résultats/i.test(b.textContent || ''));
        if (btn) btn.click();
        if (scroller) scroller.scrollTop = scroller.scrollHeight;
        window.scrollTo(0, document.body.scrollHeight);
      } catch (e) {}
      await sleep(800);
      const b = countSentByAge();
      const rows = b ? b.rows : 0;
      if (b && b.maxAge != null && b.maxAge > 8) break; // whole week is loaded
      if (rows === last) { stable++; if (stable >= 4) break; } else stable = 0;
      last = rows;
    }
  }

  // Count sent-invitation rows by age from their "Sent X <unit> ago" stamps (EN/DE/FR). Dedupes by
  // "<name>|<stamp>" so nested DOM nodes don't double-count.
  function countSentByAge() {
    const re = /(?:Sent|Gesendet|Envoy[ée])\s*(?:vor\s*)?(?:il y a\s*)?(\d+)\s*(second|Sekunde|seconde|minute|Minute|hour|Stunde|heure|day|Tag|jour|week|Woche|semaine|month|Monat|mois)s?\s*(?:ago|zuvor)?/i;
    const seen = new Map();
    const nodes = document.querySelectorAll('li, div');
    for (const el of nodes) {
      const t = el.innerText || '';
      if (t.length > 320) continue;
      const m = t.match(re);
      if (!m) continue;
      const name = (t.split('\n')[0] || '').slice(0, 60).trim();
      const key = name + '|' + m[0];
      if (!seen.has(key)) seen.set(key, ageInDays(Number(m[1]), m[2]));
    }
    if (seen.size === 0) return null;
    let d1 = 0, d7 = 0, maxAge = 0;
    for (const d of seen.values()) {
      if (d <= 1) d1++;
      if (d <= 7) d7++;
      if (d > maxAge) maxAge = d;
    }
    return { rows: seen.size, d1, d7, maxAge };
  }

  function ageInDays(n, unit) {
    unit = String(unit).toLowerCase();
    if (/second|sekunde|seconde|minute|hour|stunde|heure/.test(unit)) return 0;
    if (/day|tag|jour/.test(unit))     return n;
    if (/week|woche|semaine/.test(unit)) return n * 7;
    if (/month|monat|mois/.test(unit)) return n * 30;
    return 999;
  }

  // ── 3) PROFILE VIEWS  (/analytics/profile-views/ → /me/profile-views) ─
  // Layout: big number ABOVE the "Profile viewers" label, plus a "▲ 22% vs prior …" delta.
  function scrapeProfileViews(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const labels = ['profile viewers', 'profile views', 'Profilbesucher', 'Profil-Anzeigen', 'Profilaufrufe',
                    'vues du profil', 'visites du profil', 'visualizzazioni del profilo', 'vistas de perfil'];
    const n = countBeforeLabel(text, labels);
    if (n != null) out['Views'] = n;
    const chg = changeNear(text, labels);
    if (chg != null) out['Profile Views Change'] = chg;   // e.g. "+22%" / "-8%"
    out['_diag'] = baseDiag('profile_views', attempt);
    return out;
  }

  // ── 4) SEARCH / PROFILE APPEARANCES  (/analytics/search-appearances/) ─
  // Two headline numbers ("All appearances" + "Search appearances"), the "Where you appeared"
  // breakdown, and the week range LinkedIn reports for.
  function scrapeAppearances(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const all = countBeforeLabel(text, ['all appearances', 'alle Anzeigen', 'alle Erscheinungen', 'toutes les apparitions', 'todas las apariciones', 'tutte le comparse']);
    const search = countBeforeLabel(text, ['search appearances', 'Suchanzeigen', 'Sucherscheinungen', "apparitions dans les recherches", 'apariciones en búsquedas', 'comparse nelle ricerche']);
    if (all != null)    out['All Appearances'] = all;
    if (search != null) out['Search Appearances'] = search;

    // "Where you appeared" breakdown — capture label/percent pairs (Search 44.3%, Posts 34.5%, …).
    try {
      const sources = [];
      const re = /([A-Za-zÀ-ÿ][A-Za-zÀ-ÿ .]{2,34}?)\s*[·:\-–]\s*(\d{1,3}(?:[.,]\d)?)\s*%/g;
      let m, guard = 0;
      while ((m = re.exec(text)) && guard++ < 12) {
        const label = m[1].trim();
        const pct = parseNum(m[2]);
        if (!isNaN(pct) && pct >= 0 && pct <= 100 && label.length >= 3) sources.push({ label, pct });
      }
      if (sources.length) out['Appearance Sources'] = sources.slice(0, 6);
    } catch (e) {}

    // Week range LinkedIn reports for (e.g. "July 14 – July 20"). Best-effort, EN/DE/FR month names.
    try {
      const wk = text.match(/([A-Za-zÀ-ÿ]{3,12}\.?\s*\d{1,2})\s*[–—-]\s*((?:[A-Za-zÀ-ÿ]{3,12}\.?\s*)?\d{1,2})/);
      if (wk) out['Appearances Week'] = (wk[1] + ' – ' + wk[2]).replace(/\s+/g, ' ').trim();
    } catch (e) {}

    out['_diag'] = baseDiag('appearances', attempt);
    return out;
  }

  // ── 5) INMAIL / PREMIUM CREDITS  (/premium/sb/explore/) ─────────────
  // LinkedIn only exposes the CURRENT balance: the InMail card shows "Credits available: N".
  // We scrape that real number (plus the plan name + renewal date from the Plan Details panel).
  // The card is collapsed by default, so if the number isn't already in the DOM we expand it first.
  async function scrapePremium(attempt) {
    const out = {};
    let credits = findInMailCredits();
    if (credits == null) { expandInMailCard(); await sleep(1800); credits = findInMailCredits(); }
    if (credits == null) { expandInMailCard(); await sleep(1800); credits = findInMailCredits(); }
    if (credits != null) out['InMail Credits'] = credits;

    const text = (document.body ? document.body.innerText : '') + '\n' + (document.body ? document.body.textContent : '');
    const plan = findPlan(text);
    if (plan) out['Premium Plan'] = plan;
    const ren = text.match(/Renews?\s+on\s+([A-Za-zÀ-ÿ]+\.?\s+\d{1,2},?\s+\d{4})/i);
    if (ren) out['Premium Renews'] = ren[1].replace(/\s+/g, ' ').trim();

    out['_diag'] = Object.assign(baseDiag('premium', attempt), { credits_found: credits, plan: plan || null });
    return out;
  }

  // Search the whole DOM (textContent catches collapsed/hidden accordion content that innerText skips).
  function findInMailCredits() {
    const scan = function (str) {
      if (!str) return null;
      const m = str.match(/Credits?\s*available\s*[:\-–]?\s*(\d[\d.,  ']*)/i);
      return m ? parseCount(m[1]) : null;
    };
    const a = scan(document.body ? document.body.textContent : '');
    if (a != null) return a;
    return scan(document.body ? document.body.innerText : '');
  }

  // Click the InMail card header to expand it (only needed if the balance isn't already in the DOM).
  function expandInMailCard() {
    try {
      const els = document.querySelectorAll('button, [role="button"], [aria-expanded]');
      for (const el of els) {
        const t = (el.getAttribute('aria-label') || el.innerText || el.textContent || '').trim();
        if (/^InMail\b/i.test(t) && t.length < 60) { el.click(); return true; }
      }
    } catch (e) {}
    return false;
  }

  // Plan name from the Plan Details panel — match a known plan, else the line after "Plan Details".
  function findPlan(text) {
    const known = ['Sales Navigator Advanced Plus', 'Sales Navigator Advanced', 'Sales Navigator Core',
                   'Recruiter Lite', 'Recruiter Professional', 'Recruiter',
                   'Premium Career', 'Premium Business', 'Career', 'Business'];
    for (const k of known) { if (new RegExp(escapeRe(k), 'i').test(text)) return k; }
    const m = text.match(/Plan Details\s*\n?\s*([A-Za-z][A-Za-z .]{3,40})/i);
    return m ? m[1].trim() : null;
  }

  // ── 6) COMPANY ADMIN ANALYTICS  (/company/{id}/admin/analytics/*) ───
  // Real numbers pulled from the page-admin analytics tabs (admin-only). All are "number before
  // label" on LinkedIn, so countBeforeLabel handles them. Labels matched EN/DE/FR.
  function scrapeCoFollowers(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const total = countBeforeLabel(text, ['Total followers', 'Follower insgesamt', 'Abonnenten insgesamt', "Nombre total d'abonnés", "Total d'abonnés"]);
    const nw    = countBeforeLabel(text, ['New followers', 'Neue Follower', 'Neue Abonnenten', 'Nouveaux abonnés']);
    if (total != null) out['Company Followers'] = total;
    if (nw != null)    out['Company New Followers'] = nw;
    out['_diag'] = baseDiag('co_followers', attempt);
    return out;
  }
  function scrapeCoVisitors(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const uv = countBeforeLabel(text, ['Unique visitors', 'Eindeutige Besucher', 'Einzelne Besucher', 'Visiteurs uniques']);
    const cc = countBeforeLabel(text, ['Custom button clicks', 'Klicks auf', 'Clics sur le bouton']);
    if (uv != null) out['Company Unique Visitors'] = uv;
    if (cc != null) out['Company Custom Clicks'] = cc;
    out['_diag'] = baseDiag('co_visitors', attempt);
    return out;
  }
  function scrapeCoUpdates(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const imp = countBeforeLabel(text, ['Impressions', 'Impressionen']);
    if (imp != null) out['Company Post Impressions'] = imp;
    out['_diag'] = baseDiag('co_updates', attempt);
    return out;
  }
  function scrapeCoSearch(attempt) {
    const out = {};
    const text = document.body ? document.body.innerText : '';
    const s = countBeforeLabel(text, ['Page searches', 'Seitensuchen', 'Recherches de page', 'Search appearances', 'Sucherscheinungen']);
    if (s != null) out['Company Search Appearances'] = s;
    out['_diag'] = baseDiag('co_search', attempt);
    return out;
  }

  // ── Shared helpers ──────────────────────────────────────────────────
  function baseDiag(page, attempt) {
    const text = document.body ? document.body.innerText : '';
    return {
      page, attempt: attempt || 1, url: location.href,
      title: (document.title || '').slice(0, 120),
      text_len: text.length,
      lang: (document.documentElement.getAttribute('lang') || navigator.language || '').slice(0, 5).toLowerCase() || null,
      has_signin: /sign in|log in|anmelden|se connecter/i.test(text.slice(0, 500)),
      first_300: text.slice(0, 300),
    };
  }

  // A bounded slice of the page's METRIC region (not the nav chrome the old first_300 always caught).
  // Prefers <main>, drops the global nav/footer, collapses blank runs, caps at 2500 chars.
  function pageSample() {
    try {
      const root = document.querySelector('main') || document.querySelector('[role="main"]') || document.body;
      let t = (root && root.innerText) || '';
      t = t.replace(/\r/g, '').split('\n').map(l => l.trim()).filter(Boolean).join('\n');
      // Strip the LinkedIn global bar if it leaked in.
      t = t.replace(/^(?:Skip to (?:main|search).*|Home|My Network|Mein Netzwerk|Jobs|Messaging|Nachrichten|Notifications|Mitteilungen)\n/gim, '');
      return t.slice(0, 2500);
    } catch (e) { return null; }
  }

  function escapeRe(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }


  // Parse an integer count, stripping thousands separators (',', '.', ' ', nbsp, "'"): "29,629"→29629,
  // "29.629"→29629, "29 629"→29629. For counts every separator is a grouping separator, so we drop them all.
  function parseCount(s) {
    if (s == null) return null;
    const digits = String(s).replace(/[^\d]/g, '');
    if (!digits) return null;
    const n = parseInt(digits, 10);
    return Number.isNaN(n) ? null : n;
  }

  // Parse a decimal that may use a comma decimal separator: "44,3"→44.3, "44.3"→44.3.
  function parseNum(s) {
    if (s == null) return NaN;
    s = String(s).trim();
    if (s.indexOf(',') > -1 && s.indexOf('.') > -1) {
      if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (s.indexOf(',') > -1) {
      s = s.replace(',', '.');
    }
    return parseFloat(s);
  }

  // First count found inside a short string (e.g. an anchor's text).
  function firstCountIn(s) {
    const m = String(s).match(/(\d[\d.,  ']*)/);
    return m ? parseCount(m[1]) : null;
  }

  // ── Label→value lookup, line-oriented ──────────────────────────────
  // LinkedIn renders every analytics metric as a TILE: a label and its number on adjacent lines.
  // The old regex gap ([^\n0-9]{0,20}) could never cross that newline, so any page that put the
  // label ABOVE the number returned null — that is why Company Followers, Company Unique Visitors
  // and the appearances headlines went missing while their same-line siblings worked.
  //
  // Rules, in order:
  //   1. a number on the SAME line as the label wins ("Unique visitors: 892");
  //   2. otherwise the adjacent number-only line, above or below — but ONLY if exactly one side
  //      qualifies. If both sides are bare numbers the tile is genuinely ambiguous and we return
  //      null rather than risk reporting a neighbouring metric's value (no fake data, ever).
  function splitLines(text) {
    return String(text || '').split('\n').map(l => l.trim()).filter(Boolean);
  }

  // Is this line just a number (plus an optional delta like "▲ 22%")? Must START with a digit and
  // leave almost nothing behind, so "Letzte 30 Tage" / "Last 30 days" is correctly rejected.
  function lineNumber(line) {
    const m = /^(\d[\d.,  ']*)/.exec(line);
    if (!m) return null;
    const rest = line.slice(m[0].length)
      .replace(/[▲▼↑↓+\-]?\s*\d{1,3}([.,]\d+)?\s*%/g, '')  // trailing delta
      .replace(/[^A-Za-zÀ-ÿ]/g, '');                        // punctuation / arrows / spaces
    if (rest.length > 3) return null;
    return parseCount(m[1]);
  }

  // Which way round does THIS page stack its tiles? Decided once from every unambiguous tile on the
  // page (a text line with a bare number on exactly one side), then used to break the ties. Without
  // this, "Total followers / 1,234 / New followers / 56" is unresolvable for "New followers".
  function detectOrientation(lines, nums) {
    let below = 0, above = 0;
    for (let i = 0; i < lines.length; i++) {
      if (nums[i] != null) continue;                       // only vote from label-ish lines
      const b = i + 1 < lines.length ? nums[i + 1] : null;
      const a = i > 0 ? nums[i - 1] : null;
      if (b != null && a == null) below++;
      else if (a != null && b == null) above++;
    }
    if (below > above) return 'below';
    if (above > below) return 'above';
    return null;
  }

  // Walk from the label in `dir`, stepping over at most 2 short non-numeric lines (date ranges like
  // "Last 30 days" / "Letzte 30 Tage" sit between a label and its number), and return the number.
  function scanFor(nums, lines, i, dir) {
    let skipped = 0;
    for (let j = i + dir; j >= 0 && j < lines.length; j += dir) {
      if (nums[j] != null) return nums[j];
      if (lines[j].length > 40 || ++skipped > 2) return null;
    }
    return null;
  }

  // A number belonging to any of the localized labels.
  function countNearLabel(text, labels) {
    const lines = splitLines(text);
    const nums  = lines.map(lineNumber);
    const orient = detectOrientation(lines, nums);
    for (const label of labels) {
      const re = new RegExp(escapeRe(label), 'i');
      for (let i = 0; i < lines.length; i++) {
        const at = lines[i].search(re);
        if (at < 0) continue;
        // 1) same line — the number must sit right next to the label ("Unique visitors: 892",
        //    "Connections (711)", "711 Connections"). A number further along the line belongs to
        //    the prose, not the metric: "Search appearances in the last 7 days" must NOT yield 7.
        const after  = lines[i].slice(at + label.length);
        const before = lines[i].slice(0, at);
        let m = /^[^\d]{0,8}(\d[\d.,  ']*)/.exec(after);
        if (!m) m = /(\d[\d.,  ']*)[^\d]{0,8}$/.exec(before);
        if (m) { const n = parseCount(m[1]); if (n != null) return n; }
        // 2) the page's own tile orientation decides which side the number is on.
        if (orient) {
          const v = scanFor(nums, lines, i, orient === 'below' ? 1 : -1);
          if (v != null) return v;
          continue;
        }
        // 3) orientation unknown — accept only if exactly one neighbour is a bare number.
        const b = i + 1 < lines.length ? nums[i + 1] : null;
        const a = i > 0 ? nums[i - 1] : null;
        if (b != null && a == null) return b;
        if (a != null && b == null) return a;
        // both or neither → ambiguous. Never guess: leave it null so the receipt reports it missing.
      }
    }
    return null;
  }

  // Kept as a named alias: every caller wants the same tile lookup now.
  function countBeforeLabel(text, labels) { return countNearLabel(text, labels); }

  // A signed percentage change near a label, e.g. "▲ 22% vs prior 7 days" → "+22%", "▼ 8%" → "-8%".
  function changeNear(text, labels) {
    for (const label of labels) {
      const kw = escapeRe(label);
      // Search a window after the label for an up/down marker + percent.
      const m = text.match(new RegExp(kw + "[\\s\\S]{0,80}?([▲▼↑↓+\\-]|up|down|increase|decrease|hausse|baisse|mehr|weniger)?\\s*(\\d{1,3})\\s*%", 'i'));
      if (m) {
        const dir = (m[1] || '').toLowerCase();
        const down = /[▼↓-]|down|decrease|baisse|weniger/.test(dir);
        return (down ? '-' : '+') + m[2] + '%';
      }
    }
    return null;
  }

  // "(711)" next to a People/Pages tab label → 711.
  function parenCount(text, labels) {
    for (const label of labels) {
      const kw = escapeRe(label);
      const m = text.match(new RegExp(kw + "\\s*\\((\\d[\\d.,\\u00a0 ']*)\\)", 'i'));
      if (m) { const n = parseCount(m[1]); if (n != null) return n; }
    }
    return null;
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
})();
